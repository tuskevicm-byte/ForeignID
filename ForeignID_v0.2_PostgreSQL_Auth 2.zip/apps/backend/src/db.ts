import pg from 'pg'
import 'dotenv/config'
const {Pool}=pg
export const pool=new Pool({connectionString:process.env.DATABASE_URL})
export async function query<T=any>(text:string,params:any[]=[]){return pool.query<T>(text,params)}
